<div class="card border-left-dark">
    <div class="card-body">
        <div class="row">
            <div class="col-md-9">
                <form method="post">
                <?php 
                        if(isset($_POST['submit']))
                        {
                            $id_buku = $_POST['id_buku'];
                            $id_user = $_POST['user']['id_user'];
                            $ulasan = $_POST['ulasan'];
                            $rating = $_POST['rating'];
                            $query = mysqli_query($connection, "INSERT INTO ulasan(id_buku,id_user,ulasan,rating) values ('$id_buku','$id_user','$ulasan','$rating')");

                            if($query)
                            {
                                echo    '<script>alert("Tambah Data Berhasil");</script>';
                            }
                            else 
                            {
                                echo    '<script>alert("Tambah Data Gagal");</script>';
                            }
                        }
                        ?>
                    <div class="row mb-3">
                        <div class="col-md-4">Buku</div>
                        <div class="col-md-8">
                            <select name="id_buku" class="form-control">
                                <?php
                                $buk = mysqli_query($connection, "SELECT*FROM buku");
                                while($buku = mysqli_fetch_array($buk))
                                {
                                    ?>
                                    <option value="<?php echo $buku['id_buku']; ?>"><?php echo $buku['judul'];?></option>
                                    <?php
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">Ulasan</div>
                        <div class="col-md-8"><input type="text" class="form-control" name="ulasan"></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">Rating</div>
                        <div class="col-md-8">
                            <select name="rating" class="form-control">
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                                <option>9</option>
                                <option>10</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4"></div>
                        <div class="col-md-8">
                            <button type="submit" class="btn btn-success" name="submit" value="submit">Simpan</button>
                            <button type="reset" class="btn btn-danger">Reset</button>
                            <a href="?page-buku" class="btn btn-secondary">Kembali</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
