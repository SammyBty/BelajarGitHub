<div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">My Books</h1>
                        <a href="?page=buku_tambah" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm"><i
                        class="fas fa-download fa-sm text-white-50"></i>Tambah Buku</a>
                    </div>
<div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-secondary">Table Buku</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Kategori</th>
                                            <th>Judul</th>
                                            <th>Penulis</th>
                                            <th>Penerbit</th>
                                            <th>Tahun Terbit</th>
                                            <th>Aksi</th>
                                        </tr>
                                        <?php
                                        $i = 1;
                                            $query = mysqli_query($connection, "SELECT*FROM buku LEFT JOIN kategori ON buku.id_kategori = kategori.id_kategori");
                                            while($data = mysqli_fetch_array($query))
                                            {
                                            ?>
                                        <tbody>
                                        <tr>
                                            <td class="text-dark"><?php echo $i++; ?></td>
                                            <td class="text-dark"><?php echo $data['nama_kategori']; ?></td>
                                            <td class="text-dark"><?php echo $data['judul']; ?></td>
                                            <td class="text-dark"><?php echo $data['penulis']; ?></td>
                                            <td class="text-dark"><?php echo $data['penerbit']; ?></td>
                                            <td class="text-dark"><?php echo $data['tahun_terbit']; ?></td>
                                            <td>
                                                <a onclick="return confirm('Apakah Anda Yakin Menghapus Data Ini?');" href="?page=buku_hapus&&id=<?php echo $data['id_buku']; ?>" class="btn btn-danger btn-icon-split">
                                                    <span class="icon text-white-50">
                                                        <i class="fas fa-trash"></i>
                                                    </span>
                                                    <span class="text">Hapus</span>
                                                </a>
                                                <a href="?page=buku_ubah&&id=<?php echo $data['id_buku']; ?>" class="btn btn-warning btn-icon-split">
                                                    <span class="icon text-white-50">
                                                        <i class="fas fa-arrow-right"></i>
                                                    </span>
                                                     <span class="text">Edit</span>
                                                </a>
                                            </td>
                                        </tr>
                                        </tbody>
                                        <?php
                                            }
                                        ?>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>