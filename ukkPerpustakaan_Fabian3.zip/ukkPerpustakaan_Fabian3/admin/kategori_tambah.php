<div class="card border-left-dark">
    <div class="card-body">
        <div class="row">
            <div class="col-md-9">
                <form method="post">
                <?php 
                        if(isset($_POST['submit']))
                        {
                            $kategori = $_POST['kategori'];
                            $query = mysqli_query($connection, "INSERT INTO kategori(nama_kategori) values('$kategori')");
                            if($query)
                            {
                                echo    '<script>alert("Tambah Data Berhasil");</script>';
                            }
                            else 
                            {
                                echo    '<script>alert("Tambah Data Gagal");</script>';
                            }
                        }
                        ?>
                    <div class="row mb-3">
                        <div class="col-md-4">Nama Kategori</div>
                        <div class="col-md-8"><input type="text" class="form-control" name="kategori"></div>
                    </div>
                    <div class="row">
                        <div class="col-md-4"></div>
                        <div class="col-md-8">
                            <button type="submit" class="btn btn-success" name="submit" value="submit">Simpan</button>
                            <button type="reset" class="btn btn-danger">Reset</button>
                            <a href="?page-kategori" class="btn btn-secondary">Kembali</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
