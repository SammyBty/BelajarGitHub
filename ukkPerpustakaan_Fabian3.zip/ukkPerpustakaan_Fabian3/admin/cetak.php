<h2 align="center">Laporan Peminjaman Buku</h2>
<table border="1" cellspacing="0" cellpadding="5" width="100%">
    <thead>
            <tr>
            <th>No</th>
            <th>User</th>
            <th>Buku</th>
            <th>Tanggal Peminjaman</th>
                <th>Tanggal Pengembalian</th>
                <th>Status Peminjaman</th>
                <th>Aksi</th>
            </tr>
            <?php
            include "connection.php";
            $i = 1;
                $query = mysqli_query($connection, "SELECT*FROM peminjaman LEFT JOIN user on user.id_user = peminjaman.id_user LEFT JOIN buku on buku.id_buku = peminjaman.id_buku");
                while($data = mysqli_fetch_array($query)){
                ?>
        <tbody>
            <tr>
                <td class="text-dark"><?php echo $i++; ?></td>
                <td class="text-dark"><?php echo $data['nama_lengkap']; ?></td>
                <td class="text-dark"><?php echo $data['judul']; ?></td>
                <td class="text-dark"><?php echo $data['tanggal_peminjaman']; ?></td>
                <td class="text-dark"><?php echo $data['tanggal_pengembalian']; ?></td>
                <td class="text-dark"><?php echo $data['status_peminjaman']; ?></td>
            </tr>
        </tbody>
        <?php
                }
        ?>
    </thead>
</table>
<script>
    window.print()
    setTimeout(function()
    {
        window.close();
    }, 100);

</script>