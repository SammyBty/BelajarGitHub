<?php
$id = $_GET['id'];
$query = mysqli_query($connection, "DELETE FROM buku WHERE id_buku=$id");
?>
<script>
    alert('Hapus Data Berhasil');
    location.href = "index.php?page=buku";
</script>