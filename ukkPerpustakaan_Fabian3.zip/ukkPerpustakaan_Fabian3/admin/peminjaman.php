<div class="container-fluid">
<div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">My Booko</h1>
                        <a href="?page=peminjaman_tambah" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm"><i
                        class="fas fa-download fa-sm text-white-50 fa fa-plus"></i>Pinjam Buku</a>
                    </div>
<div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-secondary">Laporan Peminjaman</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>User</th>
                                            <th>Buku</th>
                                            <th>Tanggal Peminjaman</th>
                                            <th>Tanggal Pengembalian</th>
                                            <th>Status Peminjaman</th>
                                            <th>Aksi</th>
                                        </tr>
                                        <?php
                                        $i = 1;
                                            $query = mysqli_query($connection, "SELECT*FROM peminjaman LEFT JOIN user on user.id_user = peminjaman.id_user LEFT JOIN buku on buku.id_buku = peminjaman.id_buku WHERE peminjaman.id_user=" .$_SESSION['user']['id_user']);
                                            while($data = mysqli_fetch_array($query)){
                                            ?>
                                        <tbody>
                                        <tr>
                                            <td class="text-dark"><?php echo $i++; ?></td>
                                            <td class="text-dark"><?php echo $data['nama_lengkap']; ?></td>
                                            <td class="text-dark"><?php echo $data['judul']; ?></td>
                                            <td class="text-dark"><?php echo $data['tanggal_peminjaman']; ?></td>
                                            <td class="text-dark"><?php echo $data['tanggal_pengembalian']; ?></td>
                                            <td class="text-dark"><?php echo $data['status_peminjaman']; ?></td>
                                            <td>
                                                <?php
                                                if($data['status_peminjaman'] != 'dikembalikan')
                                                {
                                                ?>
                                                <a onclick="return confirm('Apakah Anda Yakin Menghapus Data Ini?');" href="?page=peminjaman_hapus&&id=<?php echo $data['id_peminjaman']; ?>" class="btn btn-danger btn-icon-split">
                                                    <span class="icon text-white-50">
                                                        <i class="fas fa-trash"></i>
                                                    </span>
                                                    <span class="text">Hapus</span>
                                                </a>
                                                <a href="?page=peminjaman_ubah&&id=<?php echo $data['id_peminjaman']; ?>" class="btn btn-warning btn-icon-split">
                                                    <span class="icon text-white-50">
                                                        <i class="fas fa-arrow-right"></i>
                                                    </span>
                                                        <span class="text">Edit</span>
                                                </a>
                                                <?php
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        </tbody>
                                        <?php
                                            }
                                        ?>
                                    </thead>
                                </table>
                            </div>
                        </div>
                    </div>
</div>